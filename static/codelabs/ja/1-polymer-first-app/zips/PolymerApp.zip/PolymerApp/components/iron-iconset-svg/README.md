iron-iconset-svg
=========

See the [component page](http://polymer-project.org/docs/elements/iron-elements.html#iron-iconset-svg) for more information.
