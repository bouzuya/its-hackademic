# Promise Polyfill

Note: this is an unsolicited fork of [taylorhakes/promise-polyfill](https://github.com/taylorhakes/promise-polyfill)
and should be considered experimental and unstable compared to upstream.

## Testing
```
npm install
npm test
```

## License
MIT
